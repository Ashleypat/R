This folder consists of various files. If you would like read the report we would suggest to use the pdf file (11_Koki_Patil.pdf), however if you would like to play with plots. We highly recommend to run the R markdown file (11_Koki_Patil.rmd). 

We also simulated the html for interactive plots but unfortunately we could not see our interactive plots, the pictures are then screenshoted and available in this zip file.

How to run the Rmd file?

Please set the working directory to your downloads where you downloaded our deliverable files

-> Set working directory by setwd() or by using Session - Set Working Directory - Choose Directory
-> Next we recommmend to load the datasets in this following code cell respectively ( WHR_Dataset.csv, WHO-COVID-19-global-data.csv,Cultural_Dimensions_Some_Countries.csv)


4-3 Data Retreival and Preprocessing (137-147)

```{r Reading_Data, message=FALSE, warning=FALSE, include=FALSE, results='hide'}
whr_data <- read.csv("C:/Users/kokit/OneDrive - Hochschule Luzern/Study Docuemnts/Block Week/R Bootcamp/Datasets/WHR_Dataset.csv")

covid_data <- read.csv("C:/Users/kokit/OneDrive - Hochschule Luzern/Study Docuemnts/Block Week/R Bootcamp/Datasets/WHO-COVID-19-global-data.csv")

cultural_data <- read.csv("C:/Users/kokit/OneDrive - Hochschule Luzern/Study Docuemnts/Block Week/R Bootcamp/Datasets/Cultural_Dimensions_Some_Countries.csv")

```

After you loaded the dataset please run the Rmd as Knit to HTML, you will be able to see our interactive plots as well as our shiny application.


Thank you for reading our document.